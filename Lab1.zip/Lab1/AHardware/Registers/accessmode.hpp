//
// Created by Lamerok on 21.08.2019.
//

#pragma once

//Режим доступа к регистрам
struct NoAccess {};
struct WriteMode {};
struct ReadMode {};
struct ReadWriteMode {};
