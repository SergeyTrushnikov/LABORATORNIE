#if !defined(TESTDYNAMIC_H)
#define TESTDYNAMIC_H

class TestDynamic
{
public:
  int GetI() {return i;}
private:
  int i = 0;
};


#endif // TESTDYNAMIC_H