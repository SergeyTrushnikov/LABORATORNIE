#ifndef RTOSDEFS_HPP
#define RTOSDEFS_HPP

#include "FreeRtos/rtosdefs.hpp"

#endif