#ifndef THREAD_HPP
#define THREAD_HPP

#include "FreeRtos/rtosdefs.hpp"
#include "FreeRtos/rtoswrapper.hpp"
//#include "IARConfig.h"

namespace OsWrapper
{
    constexpr tTaskEventMask defaultTaskMaskBits = 0b010101010;

    enum class StackDepth : std::uint16_t
    {
        minimal = 128U,
        medium = 256U,
        big = 512U,
        biggest = 1024U
    };

    class IThread
    {
    public:
        virtual void Execute() = 0;

        __forceinline static void Sleep(const std::chrono::milliseconds timeOut = std::chrono::milliseconds(1000))
        {
            RtosWrapper::wSleep(std::chrono::duration_cast<TicksPerSecond>(timeOut).count());
        }

        __forceinline void SleepUntil(const std::chrono::milliseconds timeOut = std::chrono::milliseconds(1000))
        {
            RtosWrapper::wSleepUntil(lastWakeTime, std::chrono::duration_cast<TicksPerSecond>(timeOut).count());
        }

        __forceinline void Signal(const tTaskEventMask mask = defaultTaskMaskBits)
        {
            RtosWrapper::wSignal(handle, mask);
        }

        __forceinline tTaskEventMask WaitForSignal(std::chrono::milliseconds timeOut = std::chrono::milliseconds(1000),
                                            const tTaskEventMask mask = defaultTaskMaskBits)
        {
            return RtosWrapper::wWaitForSignal(mask, std::chrono::duration_cast<TicksPerSecond>(timeOut).count());
        }

        friend class Rtos;
        friend class RtosWrapper;

    private:
        tTaskContext context;
        tTaskHandle handle = nullptr;
        tTime lastWakeTime = 0U;

        __forceinline void Run()
        {
            lastWakeTime = RtosWrapper::wGetTicks();
            Execute();
        }
    };

    template<std::size_t stackSize>
    class Thread : public IThread
    {
        friend class Rtos;

        static constexpr std::size_t stackDepth = stackSize;
        tStack stack[stackSize];
    };
};

#endif