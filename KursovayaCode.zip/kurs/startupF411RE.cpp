/******************************************************************************
 *  FILENAME: startupF411RE.cpp
 *  
 * DESCRIPTION: ???? ? ????????? ?????????? ??? Cortex-M. ??? ?++.
 *
 * Copyright (c) 2018 by South Ural State University
 * Author: ?????? ???????
 ******************************************************************************/

#pragma language = extended
#pragma segment = "CSTACK"

extern "C" void __iar_program_start( void );

class DummyModule
{
  public:
    static void handler();
};

using tIntFunct = void(*)();
using tIntVectItem = union {tIntFunct __fun; void * __ptr;};

// ?????????? ???????????? FreeRTOS (?? portasm.s ? port.c)
extern "C" void xPortPendSVHandler(void);
extern "C" void vPortSVCHandler(void);
extern "C" void xPortSysTickHandler(void);
extern "C" void TIM2_IRQHandler(void);

// The vector table is normally located at address 0.
#pragma location = ".intvec"
extern "C" const tIntVectItem __vector_table[] = 
{
  { .__ptr = __sfe( "CSTACK" ) },      // Initial SP
  __iar_program_start,                 // Reset handler

  // Cortex-M Core interrupts
  DummyModule::handler,                // NMI
  DummyModule::handler,                // HardFault
  DummyModule::handler,                // MemManage
  DummyModule::handler,                // BusFault
  DummyModule::handler,                // UsageFault
  0, 0, 0, 0,                          // Reserved
  vPortSVCHandler,                     // SVC
  DummyModule::handler,                // DebugMon
  0,                                   // Reserved
  xPortPendSVHandler,                  // PendSV
  xPortSysTickHandler,                 // SysTick
  
  // External Interrupts (STM32F411RE)
  DummyModule::handler,                // WWDG
  DummyModule::handler,                // PVD
  DummyModule::handler,                // TAMP_STAMP
  DummyModule::handler,                // RTC_WKUP
  DummyModule::handler,                // FLASH
  DummyModule::handler,                // RCC
  DummyModule::handler,                // EXTI0
  DummyModule::handler,                // EXTI1
  DummyModule::handler,                // EXTI2
  DummyModule::handler,                // EXTI3
  DummyModule::handler,                // EXTI4
  DummyModule::handler,                // DMA1_Stream0
  DummyModule::handler,                // DMA1_Stream1
  DummyModule::handler,                // DMA1_Stream2
  DummyModule::handler,                // DMA1_Stream3
  DummyModule::handler,                // DMA1_Stream4
  DummyModule::handler,                // DMA1_Stream5
  DummyModule::handler,                // DMA1_Stream6
  DummyModule::handler,                // ADC1
  0,                                   // USB High Priority
  0,                                   // USB Low Priority
  0,                                   // DAC
  0,                                   // COMP
  DummyModule::handler,                // EXTI9_5
  DummyModule::handler,                // TIM1_BRK_TIM9
  DummyModule::handler,                // TIM1_UP_TIM10
  DummyModule::handler,                // TIM1_TRG_COM_TIM11
  DummyModule::handler,                // TIM1_CC
  TIM2_IRQHandler,                     // TIM2
  DummyModule::handler,                // TIM3
  DummyModule::handler,                // TIM4
  DummyModule::handler,                // I2C1_EV
  DummyModule::handler,                // I2C1_ER
  DummyModule::handler,                // I2C2_EV
  DummyModule::handler,                // I2C2_ER
  DummyModule::handler,                // SPI1
  DummyModule::handler,                // SPI2
  DummyModule::handler,                // USART1
  DummyModule::handler,                // USART2
  0,                                   // USART3
  DummyModule::handler,                // EXTI15_10
  DummyModule::handler,                // RTC_Alarm
  DummyModule::handler,                // OTG_FS_WKUP
  0,                                   // TIM6
  0,                                   // TIM7
  0,                                   // Reserved
  0,                                   // Reserved
  DummyModule::handler,                // DMA1_Stream7
  0,                                   // Reserved
  DummyModule::handler,                // SDIO
  DummyModule::handler,                // TIM5
  DummyModule::handler,                // SPI3
  0,                                   // Reserved
  0,                                   // Reserved
  0,                                   // Reserved
  0,                                   // Reserved
  DummyModule::handler,                // DMA2_Stream0
  DummyModule::handler,                // DMA2_Stream1
  DummyModule::handler,                // DMA2_Stream2
  DummyModule::handler,                // DMA2_Stream3
  DummyModule::handler,                // DMA2_Stream4
  0,                                   // Reserved
  0,                                   // Reserved
  0,                                   // Reserved
  0,                                   // Reserved
  0,                                   // Reserved
  0,                                   // Reserved
  DummyModule::handler,                // OTG_FS
  DummyModule::handler,                // DMA2_Stream5
  DummyModule::handler,                // DMA2_Stream6
  DummyModule::handler,                // DMA2_Stream7
  DummyModule::handler,                // USART6
  DummyModule::handler,                // I2C3_EV
  DummyModule::handler,                // I2C3_ER
  0,                                   // Reserved
  0,                                   // Reserved
  0,                                   // Reserved
  0,                                   // Reserved
  0,                                   // Reserved
  0,                                   // Reserved
  0,                                   // Reserved
  DummyModule::handler,                // FPU
  0,                                   // Reserved
  0,                                   // Reserved
  DummyModule::handler,                // SPI4
  DummyModule::handler                 // SPI5
};

void DummyModule::handler()   
{ 
  for(;;) {} 
}

extern "C" void __cmain( void );
extern "C" __weak void __iar_init_core( void );
extern "C" __weak void __iar_init_vfp( void );

#pragma required=__vector_table
void __iar_program_start( void )
{
  __iar_init_core();
  __iar_init_vfp();
  __cmain();
}